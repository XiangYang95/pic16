Midterm Exam 1 Winter 2016 should be completed within 2 hours. It tests only material common to both tracks.

Each question in Midterm Exam 2 Winter 2016 should be completed within 1 hour. Question 1 tests material common to both tracks, Question 2 is for track A only.

Each question in Final Exam Winter 2016 should be completed within 1.5 hours. Question 1 and 2 test Track A material, question 3 tests track B material.

Additional preparatory problems for Track B:
* part 9 of Assignment 7W (NLTK)
* network part 1 of Midterm Exam 2. That is, write a program such that two people can create a drawing collaboratively from two separate computers.

Students in both tracks should get familiar with the official documentation for the modules they used. Testing new functions/classes from these modules that look related to course topics but were not specifically covered is great preparation, as you might be required (or find it useful) to read up on unfamiliar functionality during the exam.

Solutions will not be posted. A solution is any program that satisfies the prompt. After completing your own solution, individuals are encouraged to discuss/compare solutions with others. This is great for finding discrepancies between a program and the prompt and for seeing different approaches to the same problem.