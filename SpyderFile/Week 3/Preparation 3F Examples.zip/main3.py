# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 15:20:12 2016

@author: Matt
"""

def main():
    print "main() ran"
print "main3 is running"
print "its __name__ is ",__name__

if __name__ == "__main__":
    main()