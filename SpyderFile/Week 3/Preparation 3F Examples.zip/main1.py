# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 15:20:12 2016

@author: Matt
"""

def main():
    print "main() ran"
    
print "main1 is running"