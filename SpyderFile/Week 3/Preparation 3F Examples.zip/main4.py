# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 15:20:12 2016

@author: Matt
"""

import main3

print "main4 is runnning"
print "its __name__ is ",__name__