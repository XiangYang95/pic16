# -*- coding: utf-8 -*-
"""
Created on Fri Mar 16 13:40:16 2018

@author: yang0407
"""
from scipy.misc import imread
from separate import separate
from sklearn.svm import LinearSVC as LSVC

import numpy as np

def Main():
    
    alphabets = ["a", "b", "c"]
    large_imgs = [imread("{}.png".format(i), flatten = True) for i in alphabets]

    large_imgs = [separate(large_img) for large_img in large_imgs]
    small_imgs = []#will contain all 69 images/samples
    for large_img in large_imgs:#3 elements
        print len(large_img)
        for small_img in large_img:#23 each
            small_imgs.append(small_img)
    
    #resized final data        
    data = np.array([np.resize(small_img, (2000)) for small_img in small_imgs])
    print data.shape
    target = [1 for i in data]
    target[24:46] = [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]
    target[46:] = [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]
    target = np.array(target)
    train_data, train_target, test_data, test_target = Partition(data, target, 0.8)
    clf = LSVC()
    clf.fit(train_data, train_target)
    predicted_target = clf.predict(test_data)
    percentage = sum(predicted_target == test_target)*1.0/len(test_target)
    print "Predicted: ", "{}".format(predicted_target)
    print "Truth: ", "{}".format(test_target)
    print "Percentage: ", percentage
    
        
    #data_img_a = np.array(img_a).reshape((noOfCols, noOfRows))    
    
def Partition(data, target, p): 
    l = len(data)
    m = int(p*l)

    train_i = np.arange(m)
    train_i = np.random.permutation(train_i)
    
    all_i = np.arange(l)
    all_i[train_i] = -1
    test_i = all_i[all_i > -1]
    print train_i
    print test_i
    train_data = data[train_i]
    train_target = target[train_i]
    test_data = data[test_i]
    test_target = target[test_i]
    print target,test_target
    return train_data, train_target, test_data, test_target


if __name__ == "__main__":
    Main()